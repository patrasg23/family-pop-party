Family Pop Party - Repo for GitHub Pages

Contents:
- index.html
- assets/avatars/*.png and *.svg
- data/questions_el.json (40 Greek questions)
- README.md

Instructions:
1. Unzip and push to a new public GitHub repository.
2. Enable Pages in Settings -> Pages -> Source: main / root.
3. After a minute the site will be live at https://<your-username>.github.io/<repo>/
